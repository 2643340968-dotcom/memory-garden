import * as THREE from "three";
import { CONFIG } from "../config.js";

function createFallbackFlowerTexture() {
  const canvas = document.createElement("canvas");
  const context = canvas.getContext("2d");
  canvas.width = 384;
  canvas.height = 512;

  context.clearRect(0, 0, canvas.width, canvas.height);
  context.lineCap = "round";
  context.strokeStyle = "#547445";
  context.lineWidth = 13;
  context.beginPath();
  context.moveTo(192, 492);
  context.quadraticCurveTo(188, 330, 198, 170);
  context.stroke();

  context.save();
  context.translate(198, 150);
  context.fillStyle = "#9b73dc";
  for (let index = 0; index < 4; index += 1) {
    context.rotate(Math.PI / 2);
    context.beginPath();
    context.ellipse(0, -48, 28, 58, 0, 0, Math.PI * 2);
    context.fill();
  }
  context.fillStyle = "#f2dca7";
  context.beginPath();
  context.arc(0, 0, 19, 0, Math.PI * 2);
  context.fill();
  context.restore();

  const texture = new THREE.CanvasTexture(canvas);
  texture.name = "ProceduralFlowerFallback";
  return texture;
}

async function loadTexture() {
  if (CONFIG.FLOWER_ASSET_MODE !== "png") {
    return { texture: createFallbackFlowerTexture(), assetMode: "PROCEDURAL" };
  }

  try {
    const texture = await new THREE.TextureLoader().loadAsync(CONFIG.FLOWER_TEXTURE_PATH);
    texture.name = "ZijincaoTexture";
    return { texture, assetMode: "PNG" };
  } catch (error) {
    console.warn("Flower texture could not be loaded; using procedural fallback.", error);
    return { texture: createFallbackFlowerTexture(), assetMode: "FALLBACK" };
  }
}

export async function createFlowerVisual(renderer) {
  const { texture, assetMode } = await loadTexture();
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.magFilter = THREE.LinearFilter;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.anisotropy = Math.min(4, renderer.capabilities.getMaxAnisotropy());

  const imageWidth = texture.image.naturalWidth || texture.image.width || 1;
  const imageHeight = texture.image.naturalHeight || texture.image.height || 1;
  const cardAspect = imageWidth / imageHeight;
  const geometry = new THREE.PlaneGeometry(cardAspect, 1, 1, 1);
  geometry.translate(0, 0.5, 0);

  const materials = CONFIG.FLOWER_COLOR_VARIANTS.map(
    (color) =>
      new THREE.MeshBasicMaterial({
        color,
        map: texture,
        transparent: true,
        alphaTest: CONFIG.FLOWER_ALPHA_TEST,
        depthWrite: false,
        side: THREE.DoubleSide,
        fog: true,
      }),
  );
  const variantCapacity = Math.ceil(CONFIG.MAX_FLOWERS / materials.length);
  const meshes = materials.map((material, index) => {
    const mesh = new THREE.InstancedMesh(geometry, material, variantCapacity);
    mesh.name = `InstancedZijincaoFlowers-${index + 1}`;
    mesh.count = 0;
    mesh.frustumCulled = false;
    mesh.userData.instanceCapacity = variantCapacity;
    mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    return mesh;
  });

  return {
    meshes,
    texture,
    assetMode,
    variantCapacity,
    totalCapacity: variantCapacity * meshes.length,
    dispose() {
      geometry.dispose();
      materials.forEach((material) => material.dispose());
      texture.dispose();
    },
  };
}
