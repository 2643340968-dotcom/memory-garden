# Flower assets

The current demo uses a procedural four-petal card for dense cluster testing. Set `FLOWER_ASSET_MODE` to `"png"` in `src/config.js` to load `zijincao-01.png` through `src/flowers/FlowerAssetFactory.js`.

Future transparent flower cards can be added here, for example:

- `zijincao-02.png`
- `zijincao-03.png`
- `zijincao-cluster-01.png`

Update `FLOWER_TEXTURE_PATH` in `src/config.js` to switch the default card. Keep a transparent background and leave the stem base near the bottom center so growth remains anchored to the ground.
